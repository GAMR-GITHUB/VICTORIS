return {
	vic_aa = 2,
    vic_vl = 2,
	vic_vv = 2,
	vic_ch = 2,
	vic_cb = 2,
}
